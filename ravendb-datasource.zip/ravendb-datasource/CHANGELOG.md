# Changelog

## 1.0.0

Initial release.

- connectivity to http and https RavenDB instances
- support for metric queries (variables)
- support for querying (time series and regular data)
- ability to use $timeFilter and $__interval 